use rayon::prelude::*;

pub struct Person {
    pub age: u32,
}

/*
Q6: The average age of people older than 30 is 36.5
    creates a vector of Person object, num_over_30 iters with filter filts all perople with age>30
    sum_over_30 iters with map transfer Person to its age with filter does the same things for a sum
    avg calculates the average age of people older than 30
Q8: your single function:   time:   [13.205 µs 13.314 µs 13.439 µs]
                            change: [-65.660% -64.905% -64.198%] (p = 0.00 < 0.05)
                            Performance has improved.
    Found 8 outliers among 100 measurements (8.00%)
    5 (5.00%) high mild
    3 (3.00%) high severe

    Benchmarking your parallel function: : Collecting 100 samples in estimated 7.5107 s (10k iteration                                                                                                  your parallel function:                         
                            time:   [674.32 µs 704.81 µs 739.29 µs]
                            change: [-49.318% -45.100% -40.476%] (p = 0.00 < 0.05)
                            Performance has improved.
    Found 8 outliers among 100 measurements (8.00%)
    4 (4.00%) high mild
    4 (4.00%) high severe

    Answer -> according to the benchmarking, par_iter is making the program slower, maybe due to the
    small test size, cost of starting threads overweights its benefit
Q9: As long as we increase the vector size, the benefit of rayon is revealed, performance is improved
*/
pub fn part2() {
    let v: Vec<Person> = vec![
    Person { age: 23 },
    Person { age: 19 },
    Person { age: 42 },
    Person { age: 17 },
    Person { age: 17 },
    Person { age: 31 },
    Person { age: 30 },
    ];
    
    {
        let avg_over_30 = avg_age(&v);
        println!("Single: The average age of people older than 30 is {}", avg_over_30);
    }
    {
        let avg_over_30 = avg_age_parallel(&v);
        println!("Parallel: The average age of people older than 30 is {}", avg_over_30);
    }
    
}

pub fn avg_age(v: &Vec<Person>) -> f32{
    let num_over_30 = v.iter().filter(|&x| x.age > 30).count() as f32;
    let sum_over_30: u32 = v.iter().map(|x| x.age).filter(|&x| x > 30).sum();
    sum_over_30 as f32/ num_over_30
}

pub fn avg_age_parallel(v: &Vec<Person>) -> f32{
    let num_over_30 = v.par_iter().filter(|&x| x.age > 30).count() as f32;
    let sum_over_30: u32 = v.par_iter().map(|x| x.age).filter(|&x| x > 30).sum();
    sum_over_30 as f32/ num_over_30
}