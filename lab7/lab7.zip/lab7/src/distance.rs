#[repr(C)]
pub struct Point {
    x: i8,
    y: i8,
}

extern "C" {
    pub fn abs(i: i32) -> i32;
}

impl Point {
    pub fn new(x: i8, y: i8) -> Self {
        Point{x, y}
    }
}

pub fn compute_euclidean_distance(p1: &Point, p2: &Point) -> f64 {
    (((p1.x - p2.x).pow(2) + (p1.y - p2.y).pow(2)) as f64).sqrt()
}

pub fn compute_chebyshev_distance(p1: &Point, p2: &Point) -> i32 {
    let a_abs = (p2.x as i32 - p1.x as i32).abs();
    let b_abs = (p2.y as i32 - p1.y as i32).abs();
    std::cmp::max(a_abs, b_abs)
}

pub fn compute_manhattan_distance_c(p1: &Point, p2: &Point) -> i32 {
    unsafe {
        let a_abs = abs(p2.x as i32 - p1.x as i32);
        let b_abs = abs(p2.y as i32 - p1.y as i32);
        a_abs + b_abs
    }
}

pub fn compute_chebyshev_distance_c(p1: &Point, p2: &Point) -> i32 {
    unsafe {
        let a_abs = abs(p2.x as i32 - p1.x as i32);
        let b_abs = abs(p2.y as i32 - p1.y as i32);
        std::cmp::max(a_abs, b_abs)
    }
}

#[cfg(test)]
mod test {
    use super::*;

    #[test]
    fn test_euclidean_distance() {
        assert!(compute_euclidean_distance(&Point::new(2,2), &Point::new(3,4)) - 2.24 < 0.001);
    }

    #[test]
    fn test_chebyshev_distance() {
        assert_eq!(compute_chebyshev_distance(&Point::new(2,2), &Point::new(3,4)), 2);
    }

    #[test]
    fn test_chebyshev_distance_c() {
        assert_eq!(compute_chebyshev_distance_c(&Point::new(2,2), &Point::new(3,4)), 2);
    }
}