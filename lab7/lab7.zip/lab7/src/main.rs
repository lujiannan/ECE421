mod distance;
mod age;
mod julia;
mod mandelbrot;
mod julia_rayon;
mod mandelbrot_rayon;

use std::io::{self, Write};

// uncomment to run
fn main() {
    /* Part 1 */
    // part1();

    /* Part 2 */
    // part2();

    /* Julia Set */
    // julia::main().unwrap();
    // julia_rayon::main().unwrap();

    /* Mandelbrot Set */
    // mandelbrot::main().unwrap();
}

fn part1() {
    print!("Input the x coordinate of the 1st point: ");
    io::stdout().flush().unwrap();
    let p1_x = read_num();
    print!("Input the y coordinate of the 1st point: ");
    io::stdout().flush().unwrap();
    let p1_y = read_num();
    print!("Input the x coordinate of the 2nd point: ");
    io::stdout().flush().unwrap();
    let p2_x = read_num();
    print!("Input the y coordinate of the 2nd point: ");
    io::stdout().flush().unwrap();
    let p2_y = read_num();

    println!("What kind of distance do you want to use?\n(1) Euclidean\n(2) Manhattan\n(3) Chebyshev");
    io::stdout().flush().unwrap();
    let kind = read_num();

    let p1 = distance::Point::new(p1_x, p1_y);
    let p2 = distance::Point::new(p2_x, p2_y);
    match kind {
        1 => println!("Euclidean distance: {}", distance::compute_euclidean_distance(&p1, &p2)),
        2 => println!("Manhattan distance: {}", distance::compute_manhattan_distance_c(&p1, &p2)),
        3 => println!("Chebyshev distance: {}", distance::compute_chebyshev_distance_c(&p1, &p2)),
        other => println!("{other:?} is not a valid choice")
    }
}

fn part2() {
    age::part2();
}

fn read_num() -> i8 {
    // set default coordinate to be 0 if user input is not enough
    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("Failed to read line");

    // Parse the input string to extract the value for variable a
    match input.trim().parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Failed to parse input as an integer. Defaulting to 0.");
            0 // Default value if parsing fails
        }
    }
}