use criterion::{criterion_group, criterion_main, Criterion};

#[path = "../src/age.rs"]
mod age;

fn bench_single(c: &mut Criterion) {
    c.bench_function("your single function: ", |b| b.iter(|| {
        let mut v: Vec<age::Person> = Vec::new();
        for i in 1..100000 {
            v.push(age::Person { age: i });
        }
        age::avg_age(&v);
    }));   
}

fn bench_parallel(c: &mut Criterion) {
    c.bench_function("your parallel function: ", |b| b.iter(|| {
        let mut v: Vec<age::Person> = Vec::new();
        for i in 1..100000 {
            v.push(age::Person { age: i });
        }
        age::avg_age_parallel(&v);
    }));
}

criterion_group!(benches, bench_single, bench_parallel);
criterion_main!(benches);