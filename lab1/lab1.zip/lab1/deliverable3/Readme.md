**Deliverable3**:
Q1: 
The pseudo-code initialize the random number generator for an integer among 0~n, set the least sig.bit be true to make it an odd number. The purpose is to find a prime number within range 0~n.
Q2:
The code in main.rs is exactly what it needs, do cargo build && cargo run to generate a random prime number within 0~100 (can change it within main function)
Q3:
The function takes an integer, and do 5 iterations to check if the candidate is or not composite, if not, we say the integer is probably prime.
if x is congruent to candidate - 1, the candidate is considered probably prime, and the function returns true. Otherwise, it returns false
Q4:
https://crates.io/crates/glass_pumpkin
Q5:
do cargo build && cargo run to get the results