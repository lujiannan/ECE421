#![allow(dead_code)]
use roots::{find_roots_quadratic, Roots};

pub fn add(a: f64, b: f64) -> f64 {
    a + b
}

pub fn subtract(a: f64, b: f64) -> f64 {
    a - b
}

pub fn multiply(a: f64, b: f64) -> f64 {
    a * b
}

pub fn divide(a: f64, b: f64) -> f64 {
    a / b
}

pub fn square_root(a: f64) -> f64 {
    a.sqrt()
}

// ax^2 + bx + c = 0
pub fn roots(a: f64, b: f64, c: f64) -> Roots<f64> {
    find_roots_quadratic(a, b, c)
}