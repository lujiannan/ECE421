mod calculator;
fn main(){
}

#[cfg(test)]
mod question1;
mod question2;
mod question3;
mod question4;