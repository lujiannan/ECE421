use rand::prelude::*;
use hamcrest2::prelude::*;
use roots::{find_roots_quadratic, Roots};

// Note this useful idiom: importing names from outer (for mod tests) scope.
use super::*;

#[test]
pub fn test_basic_roots() {
    assert_that!(calculator::roots(1.0, 3.0, 2.0), eq(Roots::Two([-2.0, -1.0])));
}
#[test]
pub fn test_single_root() {
    assert_that!(calculator::roots(1.0, 2.0, 1.0), eq(Roots::One([-1.0])));
}
#[test]
pub fn test_random_solvable_quadratic() {
    loop {
        let mut rng = thread_rng();
        let x: f64 = rng.gen(); // random number in range [0, 1)
        let y: f64 = rng.gen();
        let z: f64 = rng.gen();
        if (y.powf(2.0) - 4.0 * x * z) < 0.0 {
            continue;
        }
        assert_that!(calculator::roots(x, y, z), eq(find_roots_quadratic(x, y, z)));
        return;
    }
}
#[test]
pub fn test_random_non_solvable_quadratic() {
	loop {
        let mut rng = thread_rng();
        let x: f64 = rng.gen(); // random number in range [0, 1)
        let y: f64 = rng.gen();
        let z: f64 = rng.gen();
        if (y.powf(2.0) - 4.0 * x * z) < 0.0 {
            assert_that!(calculator::roots(x, y, z), eq(Roots::No([])));
            return;
        }
        continue;
    }
}


   
