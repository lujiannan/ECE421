use std::io;

mod combination;
fn main(){
    println!("For question 4:");
    // Read user input for a
    println!("Enter the value of a:");
    let mut a = String::new();
    io::stdin().read_line(&mut a).expect("Failed to read line");
    let a: i32 = a.trim().parse().expect("Invalid input for a");

    // Read user input for b
    println!("Enter the value of b:");
    let mut b = String::new();
    io::stdin().read_line(&mut b).expect("Failed to read line");
    let b: i32 = b.trim().parse().expect("Invalid input for b");

    println!("Combination result is {}", combination::combine(a, b));
}

#[cfg(test)]
mod combination_test;