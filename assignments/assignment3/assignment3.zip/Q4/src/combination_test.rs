#![allow(dead_code)]
// Note this useful idiom: importing names from outer (for mod tests) scope.
use super::*;

#[test]
#[should_panic]
pub fn panic_a_smaller_than_b() {
    combination::combine(1, 2);
}

#[test]
#[should_panic]
pub fn panic_ab_not_positive() {
    combination::combine(-2, -1);
}

#[test]
#[should_panic]
pub fn panic_ab_not_integer() {
    // should be using 1.0 as income to test this case, but rust is tricky that mismatched type cannot pass compile
    // thus show my idea as a comment below in this way

    // combination::combine(-2.0, -1.0);
    panic!("a and b are not integers");
}