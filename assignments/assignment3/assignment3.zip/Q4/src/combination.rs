#![allow(dead_code)]

fn factorial(n: i32) -> i32 {
    if n == 0 {
        1
    } else {
        n * factorial(n - 1)
    }
}

pub fn combine(a: i32, b: i32) -> f64 {
    if b > a {
        panic!("b should be less than a");
    }
    f64::from(factorial(a)) / f64::from(factorial(a - b) * factorial(b))
}