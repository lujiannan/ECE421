#![allow(dead_code)]
fn main() {}

#[derive(Default)]
struct Player {
    id: i32,
    first_name: String,
    last_name: String,
}

#[cfg(test)]
mod test {
    use super::*;
    use hamcrest2::prelude::*;

    #[test]
    fn player_names_are_string() {
        let p = Player::default();
        assert_that!(p.last_name, is(type_of::<String>()));
        assert_that!(p.first_name, is(type_of::<String>()));
    }

    #[test]
    fn player_sameid_samename() {
        let p1 = Player {
            id: 0,
            first_name: String::from("jiannan"),
            last_name: String::from("lu"),
        };
        let p2 = Player {
            id: 0,
            first_name: String::from("jiannan"),
            last_name: String::from("lu"),
        };
        assert_that!(p1.id, eq(p2.id));
        assert_that!(p1.first_name, eq(p2.first_name));
        assert_that!(p1.last_name, eq(p2.last_name));
    }
}