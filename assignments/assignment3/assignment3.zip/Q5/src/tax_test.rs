#![allow(dead_code)]
// Note this useful idiom: importing names from outer (for mod tests) scope.
use super::*;

#[test]
fn tax_with_correct_type() {
    // Test with correct type (should not panic)
    assert_eq!(tax::tax(20000), 18000.0);
}

#[test]
#[should_panic]
pub fn panic_income_negative() {
    tax::tax(-1);
}

#[test]
#[should_panic]
pub fn panic_income_not_integer() {
    // should be using 1.0 as income to test this case, but rust is tricky that mismatched type cannot pass compile
    // thus show my idea as a comment below in this way

    // tax::tax(1.0);
    panic!("income is not an integer");
}