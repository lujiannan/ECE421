use std::io;

mod tax;
fn main(){
    println!("For question 5:");
    // Read user input for a
    println!("Enter the value of income:");
    let mut income = String::new();
    io::stdin().read_line(&mut income).expect("Failed to read line");
    let income: i32 = income.trim().parse().expect("Invalid input for income");
    println!("Income after tax is {}", tax::tax(income));
}

#[cfg(test)]
mod tax_test;