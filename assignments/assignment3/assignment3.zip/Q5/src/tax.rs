#![allow(dead_code)]

pub fn tax(income: i32) -> f64 {
    let income: f64 = f64::from(income);
    match income {
        i if i < 0.0 => panic!("Income should be greater than or equal to 0"),
        i if (0.0..=9999.0).contains(&i) => i,
        i if (10000.0..=49999.0).contains(&i) => i - (i * 0.1),
        i if (50000.0..=99999.0).contains(&i) => i - (i * 0.2),
        i if (100000.0..=999999.0).contains(&i) => i - (i * 0.3),
        i if i > 1000000.0 => i - (i * 0.4),
        _ => panic!("Invalid income"),
    }
}