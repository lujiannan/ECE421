pub struct UserBase {
    fname: String,
}

use bcrypt::{BcryptError, DEFAULT_COST};
use sqlite::Error as SqErr;
use chrono::NaiveDateTime;
#[derive(Debug)]
pub enum UBaseErr {
    DbErr(SqErr),
    HashError(BcryptError),
    OtherError(String),
}

impl From<SqErr> for UBaseErr {
    fn from(s: SqErr) -> Self {
        UBaseErr::DbErr(s)
    }
}
impl From<BcryptError> for UBaseErr {
    fn from(b: BcryptError) -> Self {
        UBaseErr::HashError(b)
    }
}
impl From<String> for UBaseErr {
    fn from(s: String) -> Self {
        UBaseErr::OtherError(s)
    }
}

impl UserBase {
    pub fn add_user(&self, u_name: &str, p_word: &str) -> Result<(), UBaseErr> {
        let conn = sqlite::open(&self.fname)?;
        let hpass = bcrypt::hash(p_word, DEFAULT_COST)?;
        let mut st = conn.prepare("insert into users(u_name, p_word, balance) values (?,?,0);")?;
        st.bind(1, u_name)?;
        st.bind(2, &hpass as &str)?;
        st.next()?;
        Ok(())
    }
    pub fn get_balance(&self, u_name: &str) -> Result<i64, UBaseErr> {
        let conn = sqlite::open(&self.fname)?;
        let mut st = conn.prepare("select balance from users where u_name=?;")?;
        st.bind(1, u_name)?;
        st.next()?;
        let balance: i64 = st.read(0)?;
        Ok(balance)
    }
    pub fn set_balance(&self, u_name: &str, balance: i64) -> Result<(), UBaseErr> {
        let conn = sqlite::open(&self.fname)?;
        let mut st = conn.prepare("update users set balance=? where u_name=?;")?;
        st.bind(1, balance)?;
        st.bind(2, u_name)?;
        st.next()?;
        Ok(())
    }
    pub fn pay(&self, u_from: &str, u_to: &str, amount: i64) -> Result<(), UBaseErr> {
        let conn = sqlite::open(&self.fname)?;
        let balance = self.get_balance(u_from)?;
        if balance >= amount {
            Ok(())
        } else {
            Err(format!("{} has ${}, not enough to send {}", u_from, balance, amount))
        }?;
        let mut st= conn.prepare("insert into transactions (u_from, u_to, t_date, t_amount) values(?,?,strftime(\'%Y-%m-%d %H:%M:%S\', \'now\'),?);")?;
        st.bind(1, u_from)?;
        st.bind(2, u_to)?;
        st.bind(3, amount)?;
        st.next()?;
        self.set_balance(u_from, balance - amount)?;
        let balance_to = self.get_balance(u_to)?;
        self.set_balance(u_to, balance_to + amount)?;
        Ok(())
    }
    pub fn get_transactions_history(&self, u_name: &str) -> Result<(), UBaseErr> {
        let conn = sqlite::open(&self.fname)?;
        let mut st = conn.prepare(
            "select u_from, u_to, t_date, t_amount from transactions where u_from=? or u_to=?;"
        )?;
        st.bind(1, u_name)?;
        st.bind(2, u_name)?;

        let mut count = 0;
        while let sqlite::State::Row = st.next()? {
            let from: String = st.read(0)?;
            let to: String = st.read(1)?;
            let date: String = st.read(2)?;
            let amount: String = st.read(3)?;
            let date = NaiveDateTime::parse_from_str(&date, "%Y-%m-%d %H:%M:%S");
            let date = date.unwrap().format("%d/%m/%Y %I:%M %P");
            // println!("from {} to {}", from, to);

            if to == u_name {
                println!("{} received ${} from {} on {}", u_name, amount, from, date);
                count += 1;
            } else if from == u_name {
                println!("{} sent ${} to {} on {}", u_name, amount, to, date);
                count += 1;
            }
        }
        if count != 0 {
            Ok(())
        } else {
            Err(format!("No transaction under {}", u_name))
        }?;
        Ok(())
    }
}

/*
Instructions:
Please run the cargo test with only one test at a time (while running test_add_user comment test_pay)
Because when two test are running in parallel, database cannot be edit by two thread at a time.
One approach is to set up a mutex lock for the database (but I got review for midterm,
    cannot implement that at the moment, hope you can forgive me)
*/
#[cfg(test)]
mod test {
    use super::*;
    use sqlite::{Connection, State};
    use std::thread;
    use std::time::Duration;

    // Helper function
    fn setup_db() -> Connection {
        // set up the tables for each test
        // Originally, Matt has $60, Dave has $0
        let conn = Connection::open("data/users.db").unwrap();
        conn.execute(
            "
            DROP TABLE IF EXISTS users;
            DROP TABLE IF EXISTS transactions;
            create table users(u_name text PRIMARY KEY, p_word text, balance integer);
            create table transactions(u_from text, u_to text, t_date integer, t_amount text, PRIMARY KEY(u_from,t_date), FOREIGN KEY (u_from) REFERENCES users(u_name), FOREIGN KEY (u_to) REFERENCES users(u_name));
            insert into users (u_name, p_word, balance) values ('Matt', 'matt_pw', 60), ('Dave', 'dave_pw', 0);
            ",
        )
        .unwrap();
        conn
    }

    #[test]
    fn test_add_user() {
        let conn = setup_db();
        let user_base = UserBase {
            fname: "data/users.db".into(),
        };

        let _ = user_base.add_user("test_user", "test_password").unwrap();

        // Check whether table is updated
        let mut st = conn
            .prepare("SELECT * FROM users WHERE u_name = 'test_user';")
            .unwrap();
        assert_eq!(st.next().unwrap(), State::Row);
    }

    #[test]
    fn test_pay() {
        let conn = setup_db();
        let user_base = UserBase { fname: "data/users.db".into() };

        let _ = user_base.pay("Matt", "Dave", 50);

        // Check whether table is updated
        let mut st = conn
            .prepare("SELECT * FROM transactions WHERE u_from = 'Matt' AND u_to = 'Dave';")
            .unwrap();
        assert_eq!(st.next().unwrap(), State::Row);
    }

    #[test]
    fn test_get_transaction_history() -> Result<(), UBaseErr> {
        let conn = setup_db();
        let user_base = UserBase {
            fname: "data/users.db".into(),
        };

        // because the primary key for transactions is [u_from, date], we cannot pay twice
        // from the same person at the same moment
        // thread::sleep(Duration::from_secs(1));

        println!();
        // Dave $0, Matt $60, should fail to proceed
        let _ = user_base.pay("Dave", "Matt", 10);
        // Matt $60, Dave $0, proceed, then Matt $0, Dave $60
        let _ = user_base.pay("Matt", "Dave", 60);
        // Dave $60, Matt $0, proceed, then Dave $50, Matt $10
        let _ = user_base.pay("Dave", "Matt", 10);
        println!();
        user_base.get_transactions_history("Matt")?;

        // check if Dave $50, Matt $10 after pay
        let mut st = conn.prepare("select balance from users where u_name=\'Matt\';")?;
        st.next()?;
        let balance_matt: i64 = st.read(0)?;
        let mut st = conn.prepare("select balance from users where u_name=\'Dave\';")?;
        st.next()?;
        let balance_dave: i64 = st.read(0)?;
        if balance_matt == 10 && balance_dave == 50 {
            Ok(())
        } else {
            Err(format!("Wrong balance after transaction"))
        }?;
        Ok(())
    }
}
