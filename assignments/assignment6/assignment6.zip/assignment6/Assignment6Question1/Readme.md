Tests in the project can only be run one by one, so thread = 1.
Also, the output needs to be visible with test

Instructions:
cargo test -- --test-threads=1 --nocapture
// Or leave one test case uncommented and run: cargo test -- --nocapture

Info:
Within each test's setup, originally, Matt has $60, Dave has $0