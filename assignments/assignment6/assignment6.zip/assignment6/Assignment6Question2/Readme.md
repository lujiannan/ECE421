Info:
Prerequisite is to have a data folder and 'sqlite3 users.db' run already
Every new-registered user will be grant a balance of $100 by default.
Other command-related stuff is the same as the criteria