#![allow(non_snake_case)]
mod db;

use std::env;
use std::io::{self, Write};
use sqlite::Connection;
fn main() {
    setup_db();
    let user_base = db::UserBase { fname: "data/users.db".into() };

    let args: Vec<String> = env::args().collect();

    if args.len() < 2 {
        println!("Usage: cargo run <command> [<args>]");
        return;
    }

    let command = &args[1];
    match command.as_str() {
        "new" => {
            if args.len() < 4 {
                println!("Usage: cargo run new <username> <password>");
                return;
            }
            let u_name = &args[2];
            let p_word = &args[3];

            let _ = user_base.add_user(u_name, p_word).unwrap();
            // grant a default balance of $100 by default
            let _ = user_base.set_balance(u_name, 100);

            println!("Operation done successfully!");
        }
        "transfer" => {
            if args.len() < 5 {
                println!("Usage: cargo run transfer <from_user> <to_user> <amount>");
                return;
            }
            let u_from = &args[2];
            let u_to = &args[3];
            let amount: i64 = args[4].parse().expect("Invalid amount");
            if amount <= 0 {
                println!("The amount of money transfer should be greater than 0");
                return;
            }

            print!("Please input your password: ");
            io::stdout().flush().unwrap();
            let mut password = String::new();
            io::stdin().read_line(&mut password).expect("Failed to read line");
            let password = password.trim();
            let result_login = user_base.login(u_from, password);
            match result_login {
                Ok(flag) => {
                    if !flag {
                        println!("Wrong password");
                        return;
                    }
                }
                Err(e) => println!("{:?}", e),
            }
            let result_pay = user_base.pay(u_from, u_to, amount);
            match result_pay {
                Ok(()) => println!("Operation done successfully!"),
                Err(e) => println!("{:?}", e),
            }
        }
        "balance" => {
            if args.len() < 3 {
                println!("Usage: cargo run balance <username>");
                return;
            }
            let u_name = &args[2];
            print!("Please input your password: ");
            io::stdout().flush().unwrap();
            let mut password = String::new();
            io::stdin().read_line(&mut password).expect("Failed to read line");
            let password = password.trim();
            let result_login = user_base.login(u_name, password);
            match result_login {
                Ok(flag) => {
                    if !flag {
                        println!("Wrong password");
                        return;
                    }
                }
                Err(e) => println!("{:?}", e),
            }
            let result_balance = user_base.get_balance(u_name);
            match result_balance {
                Ok(balance) => println!("Balance is ${}", balance),
                Err(e) => println!("{:?}", e),
            }
            println!("Operation done successfully!");
        }
        _ => println!("Invalid command"),
    }
}

fn setup_db() {
    // set up the tables for each test
    // Originally, Matt has $60, Dave has $0
    let conn = Connection::open("data/users.db").unwrap();
    conn.execute(
        "
        create table IF NOT EXISTS users(u_name text PRIMARY KEY, p_word text, balance integer);
        create table IF NOT EXISTS transactions(u_from text, u_to text, t_date integer, t_amount text, PRIMARY KEY(u_from,t_date), FOREIGN KEY (u_from) REFERENCES users(u_name), FOREIGN KEY (u_to) REFERENCES users(u_name));
        ",
    )
    .unwrap();
}