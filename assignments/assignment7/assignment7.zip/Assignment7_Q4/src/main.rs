extern crate rayon;
use rayon::prelude::*;

fn concurrent_quick_sort<T: PartialOrd + Send>(v: &mut [T]) {
    //add your code here:
    //uses partition fn, multiple options exist.
    //use rayon for concurrency.
    if v.len() < 2 { return; }
    let pivot = partition(v);
    let (x, y) = v.split_at_mut(pivot);
    rayon::join(|| concurrent_quick_sort(x), || concurrent_quick_sort(y));
}
fn partition<T: PartialOrd + Send>(v: &mut [T]) -> usize{
    //add your code here:
    let p = v.len() - 1;
    let mut i = 0;
    for j in 0..p {
        if v[j] <= v[p] {
            v.swap(i, j);
            i += 1;
        }
    }
    v.swap(i, p);
    i
}

fn main() {
    let mut v = vec![5,9,2,6,0,1,2];
    println!("pre-sort: {:?}", v);

    concurrent_quick_sort(&mut v);
    println!("post-sort: {:?}", v);
}
