use std::thread;
use std::time::Duration;
use std::sync::{Arc, Mutex};

// use of moved value: `sample_data`
// value moved into closure here, in previous iteration of loop
// because 'move' is used to give ownership of variables to the closure
// value is dropped as it goes out of scope of the closure
fn main() {
    let sample_data = Arc::new(Mutex::new(vec![1, 81, 107]));
    for i in 0..10 {
        let data = sample_data.clone();
        thread::spawn(move || { data.lock().unwrap()[0] += i; }); // fails here
    }
    thread::sleep(Duration::from_millis(50));
    println!("{:#?}", sample_data);
}