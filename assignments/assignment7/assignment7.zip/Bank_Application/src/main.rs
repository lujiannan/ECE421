use std::{
    sync::{Arc, Mutex},
    thread, vec,
};
use rand::Rng;

#[derive(Clone,Debug)]
struct Bank{
    accounts:Arc<Mutex<Vec<i32>>>,
}
impl Bank{
    fn new(n:usize)->Self{
        let mut v = Vec::with_capacity(n);
        for _ in 0..n{
            v.push(0);
        }
        Bank{
            accounts:Arc::new(Mutex::new(v)),
        }
    }

    fn transfer(&self, from:usize, to:usize, amount:i32)->Result<(),()>{
        let mut accounts = self.accounts.lock().unwrap();
        let bal_from = match accounts.get(from) {
            Some(a) => Ok(a),
            None => Err(())
        }?;

        if *bal_from < amount {
            println!("Error: Account {} has ${}, not enough to make this transaction", from, bal_from);
            return Err(());
        }

        accounts[from] -= amount;
        accounts[to] += amount;
        println!("Amount of ${} transferred from account id: {} to account id: {}.", amount, from, to);
        Ok(())
    }
}

struct Person{
    ac_id:usize,
    buddy_id:usize,
}
impl Person{
    pub fn new(id:usize,b_id:usize)->Self{
        Person{
            ac_id:id,
            buddy_id:b_id
        }
    }
}

fn trans(bank: &Bank, account: usize)->thread::JoinHandle<()> {
    let bank = bank.clone();
    thread::spawn(move || {
        let mut rng = rand::thread_rng();
        let buddy: i32 = rng.gen_range(0..10);
        let amount = 1;
        let person = Person::new(account, buddy as usize);
        let result = bank.transfer(person.ac_id, person.buddy_id, amount);
        if result.is_err() {
            println!("Error: transaction failed, either one of the accounts not existing")
        }
    })
}

fn main() {
    let bank = Bank {
        accounts:Arc::new(Mutex::new(vec![2,2,2,2,2,2,2,2,2,2]))
    };
    let mut threads: Vec<thread::JoinHandle<()>> = Vec::new();

    threads.push(trans(&bank, 999));    // error testing
    for i in 0..10 {
        threads.push(trans(&bank, i));
    }

    for thread in threads {
        thread.join().unwrap();
    }
}
