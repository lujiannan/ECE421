use std::cmp::Ordering;

/*
#[derive(Debug)]
struct TreeNode {
    data: &str,
    left_child: Option<TreeNode>,
    right_child: Option<TreeNode>,
}
- 'data: &str' missing lifetime specifier because it holds a reference &str, we shall tell the compiler how long it will last for.
- 'TreeNode' as a child will result in the infinite size that compile don't know the exact size of the struct
*/

#[derive(Debug, PartialEq)]
struct TreeNode<'a> {
    data: &'a str,
    left_child: Option<Box<TreeNode<'a>>>,
    right_child: Option<Box<TreeNode<'a>>>,
}

impl<'a> TreeNode<'a> {
    pub fn insert_node(&mut self, data: &'a str) {
        if self.data == data {
            return;
        }
        let new_node = if data < self.data { &mut self.left_child } else { &mut self.right_child };
        match new_node {
            // traverses the tree until it finds an empty spot to insert the node
            &mut Some(ref mut child) => child.insert_node(data),
            &mut None => {
                let node = TreeNode {
                    data,
                    left_child: None,
                    right_child: None,
                };
                let node_box = Some(Box::new(node));
                *new_node = node_box;
            }
        }
    }
}

/*
- With empty, a tree node can either be a 'Node' type that contains data and two child trees or just left as 'Empty'
- data stored in the Node must implement the Ord trait
*/
#[derive(Debug)]
pub enum Tree<T: Ord> {
    Node {
        data: T,
        left_child: Box<Tree<T>>,
        right_child: Box<Tree<T>>,
    },
    Empty,
}

impl<T: Ord> Tree<T> {
    pub fn insert_node(&mut self, new_data: T) {
        match self {
            // cases when the tree is a node or empty
            &mut Tree::Node {
                ref data,
                ref mut left_child,
                ref mut right_child,
            } => match new_data.cmp(data) {
                Ordering::Less => left_child.insert_node(new_data),
                Ordering::Greater => right_child.insert_node(new_data),
                Ordering::Equal => return,
            },
            &mut Tree::Empty => {
                *self = Tree::Node {
                    data: new_data,
                    left_child: Box::new(Tree::Empty),
                    right_child: Box::new(Tree::Empty),
                }
            }
        };
    }
}


/*
- Both have their advantages
- for struct, more straight-forward but requires explicit lifetimes while using recursion, difficult to present different states of the tree nodes (i.e. Empty)
- for enum, flexible to represent different states of the tree nodes, verbose enum structure for this simple design
*/
fn main() {
    let mut t = TreeNode {
        data: "5",
        left_child: None,
        right_child: None,
    };
    t.insert_node("5");
    t.insert_node("3");
    t.insert_node("2");
    t.insert_node("4");
    t.insert_node("7");
    t.insert_node("6");
    t.insert_node("8");
    println!("{:#?}", t);

    let mut tree: Tree<&str> = Tree::Empty;
    tree.insert_node("5");
    tree.insert_node("3");
    tree.insert_node("2");
    tree.insert_node("4");
    tree.insert_node("7");
    tree.insert_node("6");
    tree.insert_node("8");
    println!("{:#?}", tree);
}