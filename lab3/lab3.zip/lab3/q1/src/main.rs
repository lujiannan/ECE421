mod q1;

fn main() {
    println!("Question 1:");
    let mut groups = [[""; 4]; 6];
    groups[0] = ["Bob", "Carol", "Eric", "Matt"];
    groups[1] = ["Jim", "Lucy", "Terry", "Brenda"];
    groups[2] = ["Susan", "Brad", "Jim", "Matt"];
    groups[3] = ["Sue", "Wendy", "Sam", "Brad"];
    groups[4] = ["Kate", "Jack", "James", "Sydney"];
    groups[5] = ["Mary", "John", "Ricky", "Wendy"];
    q1::searchMember(&mut groups, "Jim");
    q1::searchMember(&mut groups, "Carol");
    q1::searchMember(&mut groups, "Jack");
    q1::searchMember(&mut groups, "Mary");
    q1::searchMember(&mut groups, "Leo");
    q1::searchMember(&mut groups, "Matt");
}