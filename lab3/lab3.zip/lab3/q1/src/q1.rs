pub fn searchMember(groups: &mut [[&str; 4]; 6], name: &str) {
    let mut flag = 0;
    for (group_number, group) in groups.iter().enumerate() {
        if let Some(i) = group.iter().position(|&s| s == name) {
            print!("Yes, {} exists, group {}", name, group_number);
            flag += 1;
            if i == 0 {
                println!(", leader");
            } else {
                println!(", not leader");
            }
        }
    }
    if flag == 0{
        println!("No, {} does not exists", name);
    }
}