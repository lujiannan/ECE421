pub struct UserBase {
    fname: String,
}

use bcrypt::{DEFAULT_COST, BcryptError};
use sqlite::Error as SqErr;
#[derive(Debug )]
pub enum UBaseErr{
    DbErr(SqErr),
    HashError(BcryptError)
}

impl From<SqErr> for UBaseErr{
    fn from(s:SqErr)->Self{
        UBaseErr::DbErr(s)
    }
}
impl From<BcryptError> for UBaseErr{
    fn from(b:BcryptError)->Self{
        UBaseErr::HashError(b)
    }
}

impl UserBase{
    pub fn add_user(&self, u_name:&str, p_word:&str)->Result<(),UBaseErr>{
        let conn=sqlite::open(&self.fname)?;
        let hpass=bcrypt::hash(p_word,DEFAULT_COST)?;
        let mut st= conn.prepare("insert into users(u_name, p_word) values (?,?);")?;
        st.bind(1,u_name)?;
        st.bind(2,&hpass as &str)?;
        st.next()?;
        Ok(())
    }
    pub fn pay(&self, u_from:&str, u_to:&str, amount:i64)->Result<(),UBaseErr>{
        let conn=sqlite::open(&self.fname)?;
        let mut st= conn.prepare("insert into transactions (u_from, u_to, t_date, t_amount) values(?,?,datetime(\"now\"),?);")?;
        st.bind(1,u_from)?;
        st.bind(2,u_to)?;
        st.bind(3,amount)?;
        st.next()?;
        Ok(())
    }
}
    

fn main() {}


/*
Instructions:
Please run the cargo test with only one test at a time (while running test_add_user comment test_pay)
Because when two test are running in parallel, database cannot be edit by two thread at a time.
One approach is to set up a mutex lock for the database (but I got review for midterm, 
    cannot implement that at the moment, hope you can forgive me)
*/
#[cfg(test)]
mod test {
    use super::*;
    use sqlite::{Connection, State};

    // Helper function
    fn setup_db() -> Connection {
        let conn = Connection::open("data/users.db").unwrap();
        conn.execute(
            "
            DROP TABLE IF EXISTS users;
            DROP TABLE IF EXISTS transactions;
            create table users(u_name text PRIMARY KEY, p_word text);
            create table transactions(u_from text, u_to text, t_date integer, t_amount text, PRIMARY KEY(u_from,t_date), FOREIGN KEY (u_from) REFERENCES users(u_name), FOREIGN KEY (u_to) REFERENCES users(u_name));
            insert into users (u_name, p_word) values ('Matt', 'matt_pw'), ('Dave', 'dave_pw');
            insert into transactions (u_from, u_to, t_date, t_amount) values ('Dave','Matt',datetime('now'),50);
            ",
        )
        .unwrap();
        conn
    }
    
    #[test]
    fn test_add_user() {
        let conn = setup_db();
        let user_base = UserBase { fname: "data/users.db".into() };

        let _ = user_base.add_user("test_user", "test_password").unwrap();

        // Check whether table is updated
        let mut st = conn
            .prepare("SELECT * FROM users WHERE u_name = 'test_user';")
            .unwrap();
        assert_eq!(st.next().unwrap(), State::Row);
    }

    // #[test]
    // fn test_pay() {
    //     let conn = setup_db();
    //     let user_base = UserBase { fname: "data/users.db".into() };

    //     let _ = user_base.pay("Matt", "Dave", 100);

    //     // Check whether table is updated
    //     let mut st = conn
    //         .prepare("SELECT * FROM transactions WHERE u_from = 'Matt' AND u_to = 'Dave';")
    //         .unwrap();
    //     assert_eq!(st.next().unwrap(), State::Row);
    // }
}