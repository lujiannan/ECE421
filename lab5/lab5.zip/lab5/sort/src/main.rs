#![allow(dead_code)]

pub fn selection_sort<T: std::cmp::PartialOrd>(list: &mut [T]) {
    for i in 0..list.len() {
        let mut index_min = i;
        for j in (i+1)..list.len() {
            if list[j] < list[index_min] {
                index_min = j
            }
        }
        list.swap(index_min, i);
    }
}

pub fn selection_sort_opt<T: std::cmp::Ord>(list: &mut [T]) {
    for i in 0..list.len() {
        let index_min = list[i..].iter().enumerate().min_by_key(|&(_i, val)| val).map(|(i, _val)| i);
        match index_min {
            Some(index_min) => list.swap(i, index_min + i),
            None => println!("The iterator is empty!"),
        }
    }
}

pub fn main() {
    println!("Question 1: The given machine code is implementing the selection sort. It initialie
            the array elements to 10, 0, 12, 32, loads the data from the memory to the register, 
            xor resets the value in eax to be zero, then compare the second element in the list 
            to value 32, if it's greater, set offset to be 1, and store 10 into the stack pointer + 12, 
            if it's smaller, set offset to be 0, and 10 will be stored back into stack pointer + 4, 
            which is the position of the second element, and finally unallocate the rsp");

    print!("Question 2: ");
    let mut list = vec![20, 64, 25, 12, 22, 11, 8];
    selection_sort(&mut list);
    print!("Unoptimized Sorted list -> ");
    for element in list.iter() {
        print!("{} ", element);
    }
    println!();

    println!("Question 3: Attached in the comment below");

    println!("Question 4: The length of the machine code after -O shrinks for a scale of 5, the 
            compiler with -O may mess up the order of the executable code lines to 
            achieve better performance");

    print!("Question 7: ");
    list = vec![20, 64, 25, 12, 22, 11, 8];
    selection_sort_opt(&mut list);
    print!("Optimized Sorted list -> ");
    for element in list.iter() {
        print!("{} ", element);
    }
    println!();

    println!("Question 9: The time for optimized sort is 27.764ms, faster than the unoptimized  
            one which is 31.521ms, performance has improved");

    println!("Question 10: The zero-cost abstractions is describing rust's ability to provide 
            high level abstractions without suffering from runtime overhead comparing to the 
            lower level ones. Such as, with iterator, complier analyzes your code and generate 
            efficient machine code performs as well as the handwritten ones");
}


/* The assembly code for question 3
<&T as core::fmt::Display>::fmt:
        push    rax
        mov     rdi, qword ptr [rdi]
        call    qword ptr [rip + core::fmt::num::imp::<impl core::fmt::Display for i32>::fmt@GOTPCREL]
        and     al, 1
        movzx   eax, al
        pop     rcx
        ret

<usize as core::iter::range::Step>::forward_unchecked:
        mov     rax, rdi
        add     rax, rsi
        ret

core::fmt::Arguments::new_v1:
        sub     rsp, 136
        mov     qword ptr [rsp + 8], r8
        mov     qword ptr [rsp + 16], rcx
        mov     qword ptr [rsp + 24], rdx
        mov     qword ptr [rsp + 32], rsi
        mov     qword ptr [rsp + 40], rdi
        mov     qword ptr [rsp + 48], rdi
        cmp     rdx, r8
        jb      .LBB2_2
        mov     rax, qword ptr [rsp + 24]
        mov     rcx, qword ptr [rsp + 8]
        add     rcx, 1
        cmp     rax, rcx
        ja      .LBB2_4
        jmp     .LBB2_3
.LBB2_2:
        jmp     .LBB2_4
.LBB2_3:
        mov     rax, qword ptr [rsp + 48]
        mov     rcx, qword ptr [rsp + 40]
        mov     rdx, qword ptr [rsp + 8]
        mov     rsi, qword ptr [rsp + 16]
        mov     rdi, qword ptr [rsp + 24]
        mov     r8, qword ptr [rsp + 32]
        mov     qword ptr [rsp + 104], 0
        mov     qword ptr [rcx], r8
        mov     qword ptr [rcx + 8], rdi
        mov     r8, qword ptr [rsp + 104]
        mov     rdi, qword ptr [rsp + 112]
        mov     qword ptr [rcx + 32], r8
        mov     qword ptr [rcx + 40], rdi
        mov     qword ptr [rcx + 16], rsi
        mov     qword ptr [rcx + 24], rdx
        add     rsp, 136
        ret
.LBB2_4:
        mov     qword ptr [rsp + 120], 0
        lea     rax, [rip + .L__unnamed_1]
        mov     qword ptr [rsp + 56], rax
        mov     qword ptr [rsp + 64], 1
        mov     rcx, qword ptr [rsp + 120]
        mov     rax, qword ptr [rsp + 128]
        mov     qword ptr [rsp + 88], rcx
        mov     qword ptr [rsp + 96], rax
        lea     rax, [rip + .L__unnamed_2]
        mov     qword ptr [rsp + 72], rax
        mov     qword ptr [rsp + 80], 0
        lea     rsi, [rip + .L__unnamed_3]
        mov     rax, qword ptr [rip + core::panicking::panic_fmt@GOTPCREL]
        lea     rdi, [rsp + 56]
        call    rax
        ud2

core::fmt::Arguments::new_const:
        sub     rsp, 104
        mov     qword ptr [rsp + 8], rdx
        mov     qword ptr [rsp + 16], rsi
        mov     qword ptr [rsp + 24], rdi
        mov     qword ptr [rsp + 32], rdi
        cmp     rdx, 1
        ja      .LBB3_2
        mov     rax, qword ptr [rsp + 32]
        mov     rcx, qword ptr [rsp + 24]
        mov     rdx, qword ptr [rsp + 8]
        mov     rsi, qword ptr [rsp + 16]
        mov     qword ptr [rsp + 88], 0
        mov     qword ptr [rcx], rsi
        mov     qword ptr [rcx + 8], rdx
        mov     rsi, qword ptr [rsp + 88]
        mov     rdx, qword ptr [rsp + 96]
        mov     qword ptr [rcx + 32], rsi
        mov     qword ptr [rcx + 40], rdx
        lea     rdx, [rip + .L__unnamed_2]
        mov     qword ptr [rcx + 16], rdx
        mov     qword ptr [rcx + 24], 0
        add     rsp, 104
        ret
.LBB3_2:
        lea     rsi, [rip + .L__unnamed_1]
        lea     rdi, [rsp + 40]
        mov     qword ptr [rsp], rdi
        mov     edx, 1
        call    core::fmt::Arguments::new_const
        mov     rdi, qword ptr [rsp]
        lea     rsi, [rip + .L__unnamed_4]
        mov     rax, qword ptr [rip + core::panicking::panic_fmt@GOTPCREL]
        call    rax
        ud2

core::ptr::drop_in_place<alloc::vec::Vec<i32>>:
        sub     rsp, 24
        mov     qword ptr [rsp], rdi
        mov     rax, qword ptr [rip + <alloc::vec::Vec<T,A> as core::ops::drop::Drop>::drop@GOTPCREL]
        call    rax
        jmp     .LBB4_3
.LBB4_1:
        mov     rdi, qword ptr [rsp]
        mov     rax, qword ptr [rip + core::ptr::drop_in_place<alloc::raw_vec::RawVec<i32>>@GOTPCREL]
        call    rax
        jmp     .LBB4_5
        mov     rcx, rax
        mov     eax, edx
        mov     qword ptr [rsp + 8], rcx
        mov     dword ptr [rsp + 16], eax
        jmp     .LBB4_1
.LBB4_3:
        mov     rdi, qword ptr [rsp]
        call    qword ptr [rip + core::ptr::drop_in_place<alloc::raw_vec::RawVec<i32>>@GOTPCREL]
        add     rsp, 24
        ret
        mov     rax, qword ptr [rip + core::panicking::panic_in_cleanup@GOTPCREL]
        call    rax
        ud2
.LBB4_5:
        mov     rdi, qword ptr [rsp + 8]
        call    _Unwind_Resume@PLT
        ud2

core::ptr::drop_in_place<alloc::raw_vec::RawVec<i32>>:
        push    rax
        call    qword ptr [rip + <alloc::raw_vec::RawVec<T,A> as core::ops::drop::Drop>::drop@GOTPCREL]
        pop     rax
        ret

core::iter::range::<impl core::iter::traits::iterator::Iterator for core::ops::range::Range<A>>::next:
        push    rax
        mov     rax, qword ptr [rip + <core::ops::range::Range<T> as core::iter::range::RangeIteratorImpl>::spec_next@GOTPCREL]
        call    rax
        pop     rcx
        ret

core::slice::<impl [T]>::iter:
        mov     qword ptr [rsp - 48], rdi
        mov     qword ptr [rsp - 40], rsi
        xor     eax, eax
        test    al, 1
        jne     .LBB7_2
        mov     rax, qword ptr [rsp - 48]
        mov     rcx, qword ptr [rsp - 40]
        shl     rcx, 2
        add     rax, rcx
        mov     qword ptr [rsp - 16], rax
        jmp     .LBB7_3
.LBB7_2:
        mov     rax, qword ptr [rsp - 40]
        mov     qword ptr [rsp - 16], rax
.LBB7_3:
        mov     rax, qword ptr [rsp - 48]
        mov     qword ptr [rsp - 8], rax
        mov     rax, qword ptr [rsp - 16]
        mov     rcx, qword ptr [rsp - 8]
        mov     qword ptr [rsp - 32], rcx
        mov     qword ptr [rsp - 24], rax
        mov     rax, qword ptr [rsp - 32]
        mov     rdx, qword ptr [rsp - 24]
        ret

core::slice::<impl [T]>::swap:
        sub     rsp, 56
        mov     qword ptr [rsp + 8], rdi
        mov     qword ptr [rsp + 16], rsi
        mov     qword ptr [rsp + 24], rdx
        mov     qword ptr [rsp + 32], rcx
        mov     qword ptr [rsp + 40], r8
        cmp     rdx, rsi
        setb    al
        test    al, 1
        jne     .LBB8_1
        jmp     .LBB8_2
.LBB8_1:
        mov     rax, qword ptr [rsp + 32]
        mov     rcx, qword ptr [rsp + 16]
        mov     rdx, qword ptr [rsp + 8]
        mov     rsi, qword ptr [rsp + 24]
        shl     rsi, 2
        add     rdx, rsi
        mov     qword ptr [rsp], rdx
        cmp     rax, rcx
        setb    al
        test    al, 1
        jne     .LBB8_3
        jmp     .LBB8_4
.LBB8_2:
        mov     rdx, qword ptr [rsp + 40]
        mov     rsi, qword ptr [rsp + 16]
        mov     rdi, qword ptr [rsp + 24]
        mov     rax, qword ptr [rip + core::panicking::panic_bounds_check@GOTPCREL]
        call    rax
        ud2
.LBB8_3:
        mov     rax, qword ptr [rsp + 8]
        mov     rcx, qword ptr [rsp + 32]
        mov     rdx, qword ptr [rsp]
        mov     rdi, rcx
        shl     rdi, 2
        mov     rsi, rax
        add     rsi, rdi
        mov     edi, dword ptr [rdx]
        mov     dword ptr [rsp + 52], edi
        mov     esi, dword ptr [rsi]
        mov     dword ptr [rdx], esi
        mov     edx, dword ptr [rsp + 52]
        mov     dword ptr [rax + 4*rcx], edx
        add     rsp, 56
        ret
.LBB8_4:
        mov     rdx, qword ptr [rsp + 40]
        mov     rsi, qword ptr [rsp + 16]
        mov     rdi, qword ptr [rsp + 32]
        mov     rax, qword ptr [rip + core::panicking::panic_bounds_check@GOTPCREL]
        call    rax
        ud2

alloc::alloc::exchange_malloc:
        sub     rsp, 40
        mov     qword ptr [rsp + 8], rdi
        mov     qword ptr [rsp], rsi
        mov     rsi, qword ptr [rsp]
        mov     rdx, qword ptr [rsp + 8]
        lea     rdi, [rip + .L__unnamed_2]
        xor     ecx, ecx
        call    alloc::alloc::Global::alloc_impl
        mov     qword ptr [rsp + 24], rdx
        mov     qword ptr [rsp + 16], rax
        mov     rdx, qword ptr [rsp + 16]
        xor     eax, eax
        mov     ecx, 1
        cmp     rdx, 0
        cmove   rax, rcx
        cmp     rax, 0
        jne     .LBB9_2
        mov     rax, qword ptr [rsp + 16]
        mov     qword ptr [rsp + 32], rax
        mov     rax, qword ptr [rsp + 32]
        add     rsp, 40
        ret
.LBB9_2:
        mov     rdi, qword ptr [rsp]
        mov     rsi, qword ptr [rsp + 8]
        mov     rax, qword ptr [rip + alloc::alloc::handle_alloc_error@GOTPCREL]
        call    rax
        ud2

alloc::alloc::Global::alloc_impl:
        sub     rsp, 264
        mov     al, cl
        mov     byte ptr [rsp + 15], al
        mov     qword ptr [rsp + 24], rsi
        mov     qword ptr [rsp + 32], rdx
        mov     rax, qword ptr [rsp + 32]
        mov     qword ptr [rsp + 16], rax
        cmp     rax, 0
        jne     .LBB10_2
        mov     rax, qword ptr [rsp + 24]
        mov     qword ptr [rsp + 160], rax
        mov     rax, qword ptr [rsp + 160]
        mov     qword ptr [rsp + 72], rax
        mov     rax, qword ptr [rsp + 72]
        mov     qword ptr [rsp + 184], rax
        mov     qword ptr [rsp + 192], 0
        mov     rcx, qword ptr [rsp + 184]
        mov     rax, qword ptr [rsp + 192]
        mov     qword ptr [rsp + 168], rcx
        mov     qword ptr [rsp + 176], rax
        mov     rcx, qword ptr [rsp + 168]
        mov     rax, qword ptr [rsp + 176]
        mov     qword ptr [rsp + 56], rcx
        mov     qword ptr [rsp + 64], rax
        mov     rcx, qword ptr [rsp + 56]
        mov     rax, qword ptr [rsp + 64]
        mov     qword ptr [rsp + 40], rcx
        mov     qword ptr [rsp + 48], rax
        jmp     .LBB10_3
.LBB10_2:
        mov     al, byte ptr [rsp + 15]
        test    al, 1
        jne     .LBB10_5
        jmp     .LBB10_4
.LBB10_3:
        mov     rax, qword ptr [rsp + 40]
        mov     rdx, qword ptr [rsp + 48]
        add     rsp, 264
        ret
.LBB10_4:
        mov     rcx, qword ptr [rsp + 24]
        mov     rax, qword ptr [rsp + 32]
        mov     qword ptr [rsp + 104], rcx
        mov     qword ptr [rsp + 112], rax
        mov     rax, qword ptr [rip + __rust_no_alloc_shim_is_unstable@GOTPCREL]
        mov     al, byte ptr [rax]
        mov     byte ptr [rsp + 263], al
        mov     rdi, qword ptr [rsp + 112]
        mov     rax, qword ptr [rsp + 104]
        mov     qword ptr [rsp + 208], rax
        mov     rsi, qword ptr [rsp + 208]
        call    qword ptr [rip + __rust_alloc@GOTPCREL]
        mov     qword ptr [rsp + 80], rax
        jmp     .LBB10_6
.LBB10_5:
        mov     rcx, qword ptr [rsp + 24]
        mov     rax, qword ptr [rsp + 32]
        mov     qword ptr [rsp + 88], rcx
        mov     qword ptr [rsp + 96], rax
        mov     rdi, qword ptr [rsp + 96]
        mov     rax, qword ptr [rsp + 88]
        mov     qword ptr [rsp + 200], rax
        mov     rsi, qword ptr [rsp + 200]
        call    qword ptr [rip + __rust_alloc_zeroed@GOTPCREL]
        mov     qword ptr [rsp + 80], rax
.LBB10_6:
        mov     rax, qword ptr [rsp + 80]
        mov     qword ptr [rsp], rax
        cmp     rax, 0
        jne     .LBB10_8
        mov     qword ptr [rsp + 136], 0
        jmp     .LBB10_9
.LBB10_8:
        mov     rax, qword ptr [rsp]
        mov     qword ptr [rsp + 216], rax
        mov     rax, qword ptr [rsp + 216]
        mov     qword ptr [rsp + 136], rax
.LBB10_9:
        mov     rdx, qword ptr [rsp + 136]
        mov     eax, 1
        xor     ecx, ecx
        cmp     rdx, 0
        cmove   rax, rcx
        cmp     rax, 0
        jne     .LBB10_11
        mov     qword ptr [rsp + 128], 0
        jmp     .LBB10_12
.LBB10_11:
        mov     rax, qword ptr [rsp + 136]
        mov     qword ptr [rsp + 128], rax
.LBB10_12:
        mov     rdx, qword ptr [rsp + 128]
        xor     eax, eax
        mov     ecx, 1
        cmp     rdx, 0
        cmove   rax, rcx
        cmp     rax, 0
        jne     .LBB10_14
        mov     rax, qword ptr [rsp + 128]
        mov     qword ptr [rsp + 120], rax
        jmp     .LBB10_15
.LBB10_14:
        mov     qword ptr [rsp + 120], 0
.LBB10_15:
        mov     rdx, qword ptr [rsp + 120]
        xor     eax, eax
        mov     ecx, 1
        cmp     rdx, 0
        cmove   rax, rcx
        cmp     rax, 0
        jne     .LBB10_17
        mov     rax, qword ptr [rsp + 16]
        mov     rcx, qword ptr [rsp + 120]
        mov     qword ptr [rsp + 240], rcx
        mov     qword ptr [rsp + 248], rax
        mov     rcx, qword ptr [rsp + 240]
        mov     rax, qword ptr [rsp + 248]
        mov     qword ptr [rsp + 224], rcx
        mov     qword ptr [rsp + 232], rax
        mov     rcx, qword ptr [rsp + 224]
        mov     rax, qword ptr [rsp + 232]
        mov     qword ptr [rsp + 144], rcx
        mov     qword ptr [rsp + 152], rax
        mov     rcx, qword ptr [rsp + 144]
        mov     rax, qword ptr [rsp + 152]
        mov     qword ptr [rsp + 40], rcx
        mov     qword ptr [rsp + 48], rax
        jmp     .LBB10_3
.LBB10_17:
        mov     qword ptr [rsp + 40], 0
        jmp     .LBB10_3

alloc::slice::<impl [T]>::into_vec:
        mov     rax, rdi
        mov     qword ptr [rsp - 80], rsi
        mov     qword ptr [rsp - 72], rdx
        mov     rsi, qword ptr [rsp - 80]
        mov     rcx, qword ptr [rsp - 72]
        mov     qword ptr [rsp - 64], rsi
        mov     qword ptr [rsp - 56], rcx
        mov     rsi, qword ptr [rsp - 64]
        mov     rcx, qword ptr [rsp - 56]
        mov     qword ptr [rsp - 48], rsi
        mov     qword ptr [rsp - 40], rcx
        mov     rcx, qword ptr [rsp - 48]
        mov     qword ptr [rsp - 8], rcx
        mov     rcx, qword ptr [rsp - 8]
        mov     qword ptr [rsp - 16], rcx
        mov     rcx, qword ptr [rsp - 16]
        mov     qword ptr [rsp - 32], rcx
        mov     qword ptr [rsp - 24], rdx
        mov     rsi, qword ptr [rsp - 32]
        mov     rcx, qword ptr [rsp - 24]
        mov     qword ptr [rdi], rsi
        mov     qword ptr [rdi + 8], rcx
        mov     qword ptr [rdi + 16], rdx
        ret

alloc::raw_vec::RawVec<T,A>::current_memory:
        mov     qword ptr [rsp - 88], rsi
        mov     qword ptr [rsp - 80], rdi
        mov     qword ptr [rsp - 72], rdi
        xor     eax, eax
        test    al, 1
        jne     .LBB12_2
        mov     rax, qword ptr [rsp - 88]
        cmp     qword ptr [rax + 8], 0
        jne     .LBB12_3
.LBB12_2:
        mov     rax, qword ptr [rsp - 80]
        mov     qword ptr [rax + 8], 0
        jmp     .LBB12_4
.LBB12_3:
        mov     rax, qword ptr [rsp - 80]
        mov     rcx, qword ptr [rsp - 88]
        mov     rdx, qword ptr [rcx + 8]
        shl     rdx, 2
        mov     qword ptr [rsp - 56], rdx
        mov     qword ptr [rsp - 64], 4
        mov     rcx, qword ptr [rcx]
        mov     qword ptr [rsp - 16], rcx
        mov     rcx, qword ptr [rsp - 16]
        mov     qword ptr [rsp - 8], rcx
        mov     rcx, qword ptr [rsp - 8]
        mov     qword ptr [rsp - 24], rcx
        mov     rcx, qword ptr [rsp - 24]
        mov     qword ptr [rsp - 48], rcx
        mov     rdx, qword ptr [rsp - 64]
        mov     rcx, qword ptr [rsp - 56]
        mov     qword ptr [rsp - 40], rdx
        mov     qword ptr [rsp - 32], rcx
        mov     rcx, qword ptr [rsp - 48]
        mov     qword ptr [rax], rcx
        mov     rcx, qword ptr [rsp - 40]
        mov     qword ptr [rax + 8], rcx
        mov     rcx, qword ptr [rsp - 32]
        mov     qword ptr [rax + 16], rcx
.LBB12_4:
        mov     rax, qword ptr [rsp - 72]
        ret

<I as core::iter::traits::collect::IntoIterator>::into_iter:
        mov     rdx, rsi
        mov     rax, rdi
        ret

<I as core::iter::traits::collect::IntoIterator>::into_iter:
        mov     rdx, rsi
        mov     rax, rdi
        ret

<alloc::alloc::Global as core::alloc::Allocator>::deallocate:
        sub     rsp, 56
        mov     qword ptr [rsp + 8], rsi
        mov     qword ptr [rsp + 16], rdx
        mov     qword ptr [rsp + 24], rcx
        cmp     qword ptr [rsp + 24], 0
        jne     .LBB15_2
        jmp     .LBB15_3
.LBB15_2:
        mov     rdi, qword ptr [rsp + 8]
        mov     rcx, qword ptr [rsp + 16]
        mov     rax, qword ptr [rsp + 24]
        mov     qword ptr [rsp + 32], rcx
        mov     qword ptr [rsp + 40], rax
        mov     rsi, qword ptr [rsp + 40]
        mov     rax, qword ptr [rsp + 32]
        mov     qword ptr [rsp + 48], rax
        mov     rdx, qword ptr [rsp + 48]
        call    qword ptr [rip + __rust_dealloc@GOTPCREL]
.LBB15_3:
        add     rsp, 56
        ret

<alloc::vec::Vec<T,A> as core::ops::drop::Drop>::drop:
        mov     rcx, qword ptr [rdi]
        mov     rax, qword ptr [rdi + 16]
        mov     qword ptr [rsp - 16], rcx
        mov     qword ptr [rsp - 8], rax
        mov     rcx, qword ptr [rsp - 16]
        mov     rax, qword ptr [rsp - 8]
        mov     qword ptr [rsp - 32], rcx
        mov     qword ptr [rsp - 24], rax
        ret

<alloc::vec::Vec<T,A> as core::ops::deref::Deref>::deref:
        mov     rcx, qword ptr [rdi]
        mov     rax, qword ptr [rdi + 16]
        mov     qword ptr [rsp - 16], rcx
        mov     qword ptr [rsp - 8], rax
        mov     rcx, qword ptr [rsp - 16]
        mov     rax, qword ptr [rsp - 8]
        mov     qword ptr [rsp - 32], rcx
        mov     qword ptr [rsp - 24], rax
        mov     rax, qword ptr [rsp - 32]
        mov     rdx, qword ptr [rsp - 24]
        ret

<alloc::vec::Vec<T,A> as core::ops::deref::DerefMut>::deref_mut:
        mov     rcx, qword ptr [rdi]
        mov     rax, qword ptr [rdi + 16]
        mov     qword ptr [rsp - 16], rcx
        mov     qword ptr [rsp - 8], rax
        mov     rcx, qword ptr [rsp - 16]
        mov     rax, qword ptr [rsp - 8]
        mov     qword ptr [rsp - 32], rcx
        mov     qword ptr [rsp - 24], rax
        mov     rax, qword ptr [rsp - 32]
        mov     rdx, qword ptr [rsp - 24]
        ret

<alloc::raw_vec::RawVec<T,A> as core::ops::drop::Drop>::drop:
        sub     rsp, 40
        mov     rsi, rdi
        mov     qword ptr [rsp + 8], rsi
        lea     rdi, [rsp + 16]
        call    qword ptr [rip + alloc::raw_vec::RawVec<T,A>::current_memory@GOTPCREL]
        mov     eax, 1
        xor     ecx, ecx
        cmp     qword ptr [rsp + 24], 0
        cmove   rax, rcx
        cmp     rax, 1
        jne     .LBB19_2
        mov     rdi, qword ptr [rsp + 8]
        mov     rsi, qword ptr [rsp + 16]
        mov     rdx, qword ptr [rsp + 24]
        mov     rcx, qword ptr [rsp + 32]
        add     rdi, 16
        call    <alloc::alloc::Global as core::alloc::Allocator>::deallocate
.LBB19_2:
        add     rsp, 40
        ret

<core::ops::range::Range<T> as core::iter::range::RangeIteratorImpl>::spec_next:
        sub     rsp, 40
        mov     qword ptr [rsp + 16], rdi
        mov     rax, qword ptr [rdi]
        cmp     rax, qword ptr [rdi + 8]
        jb      .LBB20_2
        mov     qword ptr [rsp + 24], 0
        jmp     .LBB20_3
.LBB20_2:
        mov     rax, qword ptr [rsp + 16]
        mov     rdi, qword ptr [rax]
        mov     qword ptr [rsp + 8], rdi
        mov     esi, 1
        call    <usize as core::iter::range::Step>::forward_unchecked
        mov     rcx, qword ptr [rsp + 16]
        mov     rdx, rax
        mov     rax, qword ptr [rsp + 8]
        mov     qword ptr [rcx], rdx
        mov     qword ptr [rsp + 32], rax
        mov     qword ptr [rsp + 24], 1
.LBB20_3:
        mov     rax, qword ptr [rsp + 24]
        mov     rdx, qword ptr [rsp + 32]
        add     rsp, 40
        ret

<core::slice::iter::Iter<T> as core::iter::traits::iterator::Iterator>::next:
        mov     qword ptr [rsp - 48], rdi
        xor     eax, eax
        test    al, 1
        jne     .LBB21_2
        mov     rax, qword ptr [rsp - 48]
        mov     rcx, qword ptr [rax + 8]
        mov     qword ptr [rsp - 24], rcx
        mov     rax, qword ptr [rax]
        cmp     rax, qword ptr [rsp - 24]
        sete    al
        and     al, 1
        mov     byte ptr [rsp - 25], al
        jmp     .LBB21_3
.LBB21_2:
        mov     rax, qword ptr [rsp - 48]
        mov     rax, qword ptr [rax + 8]
        cmp     rax, 0
        sete    al
        and     al, 1
        mov     byte ptr [rsp - 25], al
.LBB21_3:
        test    byte ptr [rsp - 25], 1
        jne     .LBB21_5
        mov     rax, qword ptr [rsp - 48]
        mov     rax, qword ptr [rax]
        mov     qword ptr [rsp - 16], rax
        xor     eax, eax
        test    al, 1
        jne     .LBB21_7
        jmp     .LBB21_6
.LBB21_5:
        mov     qword ptr [rsp - 40], 0
        jmp     .LBB21_9
.LBB21_6:
        mov     rax, qword ptr [rsp - 48]
        mov     rcx, qword ptr [rax]
        add     rcx, 4
        mov     qword ptr [rsp - 8], rcx
        mov     rcx, qword ptr [rsp - 8]
        mov     qword ptr [rax], rcx
        jmp     .LBB21_8
.LBB21_7:
        mov     rax, qword ptr [rsp - 48]
        mov     rcx, qword ptr [rax + 8]
        sub     rcx, 1
        mov     qword ptr [rax + 8], rcx
.LBB21_8:
        mov     rax, qword ptr [rsp - 16]
        mov     qword ptr [rsp - 40], rax
.LBB21_9:
        mov     rax, qword ptr [rsp - 40]
        ret

example::selection_sort:
        sub     rsp, 168
        mov     qword ptr [rsp + 48], rdi
        mov     qword ptr [rsp + 56], rsi
        mov     qword ptr [rsp + 64], 0
        mov     qword ptr [rsp + 72], rsi
        mov     rdi, qword ptr [rsp + 64]
        mov     rsi, qword ptr [rsp + 72]
        call    qword ptr [rip + <I as core::iter::traits::collect::IntoIterator>::into_iter@GOTPCREL]
        mov     qword ptr [rsp + 80], rax
        mov     qword ptr [rsp + 88], rdx
.LBB22_1:
        mov     rax, qword ptr [rip + core::iter::range::<impl core::iter::traits::iterator::Iterator for core::ops::range::Range<A>>::next@GOTPCREL]
        lea     rdi, [rsp + 80]
        call    rax
        mov     qword ptr [rsp + 104], rdx
        mov     qword ptr [rsp + 96], rax
        cmp     qword ptr [rsp + 96], 0
        jne     .LBB22_3
        add     rsp, 168
        ret
.LBB22_3:
        mov     rax, qword ptr [rsp + 104]
        mov     qword ptr [rsp + 32], rax
        mov     qword ptr [rsp + 112], rax
        add     rax, 1
        mov     qword ptr [rsp + 40], rax
        setb    al
        test    al, 1
        jne     .LBB22_5
        mov     rax, qword ptr [rsp + 56]
        mov     rcx, qword ptr [rsp + 40]
        mov     qword ptr [rsp + 120], rcx
        mov     qword ptr [rsp + 128], rax
        mov     rdi, qword ptr [rsp + 120]
        mov     rsi, qword ptr [rsp + 128]
        call    qword ptr [rip + <I as core::iter::traits::collect::IntoIterator>::into_iter@GOTPCREL]
        mov     qword ptr [rsp + 136], rax
        mov     qword ptr [rsp + 144], rdx
        jmp     .LBB22_6
.LBB22_5:
        lea     rdi, [rip + str.0]
        lea     rdx, [rip + .L__unnamed_5]
        mov     rax, qword ptr [rip + core::panicking::panic@GOTPCREL]
        mov     esi, 28
        call    rax
        ud2
.LBB22_6:
        mov     rax, qword ptr [rip + core::iter::range::<impl core::iter::traits::iterator::Iterator for core::ops::range::Range<A>>::next@GOTPCREL]
        lea     rdi, [rsp + 136]
        call    rax
        mov     qword ptr [rsp + 160], rdx
        mov     qword ptr [rsp + 152], rax
        cmp     qword ptr [rsp + 152], 0
        jne     .LBB22_8
        mov     rcx, qword ptr [rsp + 32]
        mov     rsi, qword ptr [rsp + 56]
        mov     rdi, qword ptr [rsp + 48]
        mov     rdx, qword ptr [rsp + 112]
        lea     r8, [rip + .L__unnamed_6]
        call    qword ptr [rip + core::slice::<impl [T]>::swap@GOTPCREL]
        jmp     .LBB22_1
.LBB22_8:
        mov     rcx, qword ptr [rsp + 56]
        mov     rax, qword ptr [rsp + 160]
        mov     qword ptr [rsp + 24], rax
        cmp     rax, rcx
        setb    al
        test    al, 1
        jne     .LBB22_9
        jmp     .LBB22_10
.LBB22_9:
        mov     rcx, qword ptr [rsp + 56]
        mov     rax, qword ptr [rsp + 48]
        mov     rdx, qword ptr [rsp + 24]
        shl     rdx, 2
        add     rax, rdx
        mov     qword ptr [rsp + 8], rax
        mov     rax, qword ptr [rsp + 112]
        mov     qword ptr [rsp + 16], rax
        cmp     rax, rcx
        setb    al
        test    al, 1
        jne     .LBB22_11
        jmp     .LBB22_12
.LBB22_10:
        mov     rsi, qword ptr [rsp + 56]
        mov     rdi, qword ptr [rsp + 24]
        lea     rdx, [rip + .L__unnamed_7]
        mov     rax, qword ptr [rip + core::panicking::panic_bounds_check@GOTPCREL]
        call    rax
        ud2
.LBB22_11:
        mov     rcx, qword ptr [rsp + 48]
        mov     rdx, qword ptr [rsp + 16]
        mov     rax, qword ptr [rsp + 8]
        mov     eax, dword ptr [rax]
        cmp     eax, dword ptr [rcx + 4*rdx]
        jl      .LBB22_13
        jmp     .LBB22_6
.LBB22_12:
        mov     rsi, qword ptr [rsp + 56]
        mov     rdi, qword ptr [rsp + 16]
        lea     rdx, [rip + .L__unnamed_8]
        mov     rax, qword ptr [rip + core::panicking::panic_bounds_check@GOTPCREL]
        call    rax
        ud2
.LBB22_13:
        mov     rax, qword ptr [rsp + 24]
        mov     qword ptr [rsp + 112], rax
        jmp     .LBB22_6

example::main:
        sub     rsp, 456
        lea     rdi, [rsp + 112]
        lea     rsi, [rip + .L__unnamed_9]
        mov     edx, 1
        call    core::fmt::Arguments::new_const
        lea     rdi, [rsp + 112]
        call    qword ptr [rip + std::io::stdio::_print@GOTPCREL]
        lea     rdi, [rsp + 160]
        lea     rsi, [rip + .L__unnamed_10]
        mov     edx, 1
        call    core::fmt::Arguments::new_const
        lea     rdi, [rsp + 160]
        call    qword ptr [rip + std::io::stdio::_print@GOTPCREL]
        mov     edi, 20
        mov     esi, 4
        call    alloc::alloc::exchange_malloc
        mov     qword ptr [rsp + 104], rax
        and     rax, 3
        cmp     rax, 0
        sete    al
        test    al, 1
        jne     .LBB23_1
        jmp     .LBB23_2
.LBB23_1:
        mov     rsi, qword ptr [rsp + 104]
        mov     dword ptr [rsi], 64
        mov     dword ptr [rsi + 4], 25
        mov     dword ptr [rsi + 8], 12
        mov     dword ptr [rsi + 12], 22
        mov     dword ptr [rsi + 16], 11
        mov     rax, qword ptr [rip + alloc::slice::<impl [T]>::into_vec@GOTPCREL]
        lea     rdi, [rsp + 208]
        mov     qword ptr [rsp + 80], rdi
        mov     edx, 5
        call    rax
        mov     rdi, qword ptr [rsp + 80]
        mov     rax, qword ptr [rip + <alloc::vec::Vec<T,A> as core::ops::deref::DerefMut>::deref_mut@GOTPCREL]
        call    rax
        mov     qword ptr [rsp + 88], rdx
        mov     qword ptr [rsp + 96], rax
        jmp     .LBB23_5
.LBB23_2:
        mov     rsi, qword ptr [rsp + 104]
        lea     rdx, [rip + .L__unnamed_11]
        mov     rax, qword ptr [rip + core::panicking::panic_misaligned_pointer_dereference@GOTPCREL]
        mov     edi, 4
        call    rax
        ud2
.LBB23_3:
        mov     rax, qword ptr [rip + core::ptr::drop_in_place<alloc::vec::Vec<i32>>@GOTPCREL]
        lea     rdi, [rsp + 208]
        call    rax
        jmp     .LBB23_22
        mov     rcx, rax
        mov     eax, edx
        mov     qword ptr [rsp + 424], rcx
        mov     dword ptr [rsp + 432], eax
        jmp     .LBB23_3
.LBB23_5:
        mov     rsi, qword ptr [rsp + 88]
        mov     rdi, qword ptr [rsp + 96]
        mov     rax, qword ptr [rip + example::selection_sort@GOTPCREL]
        call    rax
        jmp     .LBB23_6
.LBB23_6:
        lea     rsi, [rip + .L__unnamed_12]
        lea     rdi, [rsp + 232]
        mov     edx, 1
        call    core::fmt::Arguments::new_const
        jmp     .LBB23_7
.LBB23_7:
        mov     rax, qword ptr [rip + std::io::stdio::_print@GOTPCREL]
        lea     rdi, [rsp + 232]
        call    rax
        jmp     .LBB23_8
.LBB23_8:
        mov     rax, qword ptr [rip + <alloc::vec::Vec<T,A> as core::ops::deref::Deref>::deref@GOTPCREL]
        lea     rdi, [rsp + 208]
        call    rax
        mov     qword ptr [rsp + 64], rdx
        mov     qword ptr [rsp + 72], rax
        jmp     .LBB23_9
.LBB23_9:
        mov     rsi, qword ptr [rsp + 64]
        mov     rdi, qword ptr [rsp + 72]
        mov     rax, qword ptr [rip + core::slice::<impl [T]>::iter@GOTPCREL]
        call    rax
        mov     qword ptr [rsp + 48], rdx
        mov     qword ptr [rsp + 56], rax
        jmp     .LBB23_10
.LBB23_10:
        mov     rsi, qword ptr [rsp + 48]
        mov     rdi, qword ptr [rsp + 56]
        mov     rax, qword ptr [rip + <I as core::iter::traits::collect::IntoIterator>::into_iter@GOTPCREL]
        call    rax
        mov     qword ptr [rsp + 32], rdx
        mov     qword ptr [rsp + 40], rax
        jmp     .LBB23_11
.LBB23_11:
        mov     rax, qword ptr [rsp + 32]
        mov     rcx, qword ptr [rsp + 40]
        mov     qword ptr [rsp + 280], rcx
        mov     qword ptr [rsp + 288], rax
.LBB23_12:
        mov     rax, qword ptr [rip + <core::slice::iter::Iter<T> as core::iter::traits::iterator::Iterator>::next@GOTPCREL]
        lea     rdi, [rsp + 280]
        call    rax
        mov     qword ptr [rsp + 24], rax
        jmp     .LBB23_13
.LBB23_13:
        mov     rax, qword ptr [rsp + 24]
        mov     qword ptr [rsp + 296], rax
        mov     rdx, qword ptr [rsp + 296]
        mov     eax, 1
        xor     ecx, ecx
        cmp     rdx, 0
        cmove   rax, rcx
        cmp     rax, 0
        jne     .LBB23_15
        lea     rsi, [rip + .L__unnamed_13]
        lea     rdi, [rsp + 376]
        mov     edx, 1
        call    core::fmt::Arguments::new_const
        jmp     .LBB23_16
.LBB23_15:
        mov     rax, qword ptr [rsp + 296]
        mov     qword ptr [rsp + 304], rax
        lea     rax, [rsp + 304]
        mov     qword ptr [rsp + 440], rax
        mov     rax, qword ptr [rip + <&T as core::fmt::Display>::fmt@GOTPCREL]
        mov     qword ptr [rsp + 448], rax
        mov     rax, qword ptr [rsp + 440]
        mov     qword ptr [rsp + 8], rax
        mov     rax, qword ptr [rsp + 448]
        mov     qword ptr [rsp + 16], rax
        jmp     .LBB23_18
.LBB23_16:
        mov     rax, qword ptr [rip + std::io::stdio::_print@GOTPCREL]
        lea     rdi, [rsp + 376]
        call    rax
        jmp     .LBB23_17
.LBB23_17:
        lea     rdi, [rsp + 208]
        call    qword ptr [rip + core::ptr::drop_in_place<alloc::vec::Vec<i32>>@GOTPCREL]
        add     rsp, 456
        ret
.LBB23_18:
        mov     rax, qword ptr [rsp + 16]
        mov     rcx, qword ptr [rsp + 8]
        mov     qword ptr [rsp + 360], rcx
        mov     qword ptr [rsp + 368], rax
        lea     rsi, [rip + .L__unnamed_14]
        lea     rdi, [rsp + 312]
        mov     edx, 2
        lea     rcx, [rsp + 360]
        mov     r8d, 1
        call    core::fmt::Arguments::new_v1
        jmp     .LBB23_19
.LBB23_19:
        mov     rax, qword ptr [rip + std::io::stdio::_print@GOTPCREL]
        lea     rdi, [rsp + 312]
        call    rax
        jmp     .LBB23_20
.LBB23_20:
        jmp     .LBB23_12
        mov     rax, qword ptr [rip + core::panicking::panic_in_cleanup@GOTPCREL]
        call    rax
        ud2
.LBB23_22:
        mov     rdi, qword ptr [rsp + 424]
        call    _Unwind_Resume@PLT
        ud2

.L__unnamed_15:
        .ascii  "invalid args"

.L__unnamed_1:
        .quad   .L__unnamed_15
        .asciz  "\f\000\000\000\000\000\000"

.L__unnamed_2:

.L__unnamed_16:
        .ascii  "/rustc/82e1608dfa6e0b5569232559e3d385fea5a93112/library/core/src/fmt/mod.rs"

.L__unnamed_3:
        .quad   .L__unnamed_16
        .asciz  "K\000\000\000\000\000\000\000M\001\000\000\r\000\000"

.L__unnamed_4:
        .quad   .L__unnamed_16
        .asciz  "K\000\000\000\000\000\000\000C\001\000\000\r\000\000"

.L__unnamed_17:
        .ascii  "/app/example.rs"

.L__unnamed_5:
        .quad   .L__unnamed_17
        .asciz  "\017\000\000\000\000\000\000\000\004\000\000\000\022\000\000"

str.0:
        .ascii  "attempt to add with overflow"

.L__unnamed_6:
        .quad   .L__unnamed_17
        .asciz  "\017\000\000\000\000\000\000\000\t\000\000\000\016\000\000"

.L__unnamed_7:
        .quad   .L__unnamed_17
        .asciz  "\017\000\000\000\000\000\000\000\005\000\000\000\020\000\000"

.L__unnamed_8:
        .quad   .L__unnamed_17
        .asciz  "\017\000\000\000\000\000\000\000\005\000\000\000\032\000\000"

.L__unnamed_18:
        .ascii  "Question 1: The given machine code is implementing the selection sort\n"

.L__unnamed_9:
        .quad   .L__unnamed_18
        .asciz  "F\000\000\000\000\000\000"

.L__unnamed_19:
        .ascii  "Question 2: "

.L__unnamed_10:
        .quad   .L__unnamed_19
        .asciz  "\f\000\000\000\000\000\000"

.L__unnamed_11:
        .quad   .L__unnamed_17
        .asciz  "\017\000\000\000\000\000\000\000\021\000\000\000\024\000\000"

.L__unnamed_20:
        .ascii  "Sorted list: "

.L__unnamed_12:
        .quad   .L__unnamed_20
        .asciz  "\r\000\000\000\000\000\000"

.L__unnamed_21:
        .byte   10

.L__unnamed_13:
        .quad   .L__unnamed_21
        .asciz  "\001\000\000\000\000\000\000"

.L__unnamed_22:
        .byte   32

.L__unnamed_14:
        .quad   .L__unnamed_2
        .zero   8
        .quad   .L__unnamed_22
        .asciz  "\001\000\000\000\000\000\000"

DW.ref.rust_eh_personality:
        .quad   rust_eh_personality
*/