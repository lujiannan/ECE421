use criterion::{black_box, criterion_group, criterion_main, Criterion};
use rand::{thread_rng, Rng};
#[path = "../src/main.rs"]
mod main;

fn bench_selection_sort(c: &mut Criterion) {
    let mut rng = thread_rng();
    let mut l: Vec<i64> = (0..10000).map(|_| {rng.gen_range(1, 10000)}).collect();
    c.bench_function("selection_sort: ", |b| b.iter(|| main::selection_sort::<i64>(black_box(&mut l))));
}

fn bench_selection_sort_opt(c: &mut Criterion) {
    let mut rng = thread_rng();
    let mut l: Vec<i64> = (0..10000).map(|_| {rng.gen_range(1, 10000)}).collect();
    c.bench_function("selection_sort_opt: ", |b| b.iter(|| main::selection_sort_opt::<i64>(black_box(&mut l))));
}

criterion_group!(benches, bench_selection_sort, bench_selection_sort_opt);
criterion_main!(benches);