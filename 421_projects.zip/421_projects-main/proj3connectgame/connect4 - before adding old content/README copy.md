# Our crate Set of Binary Trees (Red-Black tree and AVL tree)
- ECE421 Group Project 3, due Apr 12?, 2024  
- Version: 1.0.0
- Authors: Prabh Kooner, Jiannan Lu, Brandon Hoynick

