# ECE421 W24 Group#1 Projects
- Authors: Prabh Kooner, Brandon Hoynick, Jiannan Lu  