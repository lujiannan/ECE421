mod utils;

use primes;
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
extern "C" {
    fn alert(s: &str);
}

#[wasm_bindgen]
pub fn greet() {
    alert("Hello, wasm-is-prime!");
}

#[wasm_bindgen]
pub fn check_prime(s: &JsValue) -> u32 {
    let input: String = s.as_string().unwrap();
    if is_prime(input) {
        // alert("Input is Prime");
        1
    } else {
        // alert("Input is NOT Prime");
        0
    }
}

fn is_prime(s: String)-> bool {
    // add your code to check prime here
    primes::is_prime(s.parse().expect("Invalid input"))
}
