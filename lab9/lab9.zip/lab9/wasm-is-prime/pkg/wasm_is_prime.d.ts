/* tslint:disable */
/* eslint-disable */
/**
*/
export function greet(): void;
/**
* @param {any} s
* @returns {number}
*/
export function check_prime(s: any): number;
