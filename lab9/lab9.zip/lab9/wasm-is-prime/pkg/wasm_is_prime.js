import * as wasm from "./wasm_is_prime_bg.wasm";
import { __wbg_set_wasm } from "./wasm_is_prime_bg.js";
__wbg_set_wasm(wasm);
export * from "./wasm_is_prime_bg.js";
