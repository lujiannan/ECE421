/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function check_prime(a: number): number;
export function greet(): void;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
